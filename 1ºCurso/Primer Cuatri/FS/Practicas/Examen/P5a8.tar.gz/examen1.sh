#!/bin/bash
# Examen FS 22/12/20
# Creado por Yeray Lopez Ramirez

case $1 in

	--h)printf "Ayuda\n--p <fichero_fuente> <fichero_destino> Copia el fichero fuente en el destino.\n"
	    printf "\n--p solo<directrio_destino> (si no existe se crea). Copia los ficheros del planos del directorio de trabajo en el directorio_destino.\n"
	    printf "\n--h (sin argumentos) Muestra esta ayuda.\n"
;;
	--p)if [ $# == 3 ];then
		if  [ -f $2 ] && [ -f $3 ] ; then
		   cat $2 > $3
		else
		   printf "\n Los argumentos introducidos no son archivos o no existen"
	        fi
	     elif [ $# == 2 ];then
	     	if [ -d $2 ];then
	     	   cp ./* $2
	     	   printf "archivos copiados a %s \n" $2
	     	else
	     	   printf "El argumento no es un directorio o no existe\n"
	     	fi
	     else
	     	printf "Numero de argumentos incorrecto:\nUse el argumento '--h' sin argumentos extra para informacion sobre el script\n"
	     fi
;;
	--sh)if [ $# != 2 ]; then

	echo "Uso: $0 -sh <shells>"
	
	exit 1
	
fi
	cat /etc/shells | grep $2
	     if [ $? == 1 ];then
		echo "Debe introducir las siguientes shells: "
		cat /etc/shells
	     else
		echo "Usuarios con la shell $2: "  
		cat /etc/passwd | grep $2 | cut -d ":" -f2 | sort
		   
	      fi
;;  
esac
