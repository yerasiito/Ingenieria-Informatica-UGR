#include <iostream>
#include "functions.h"

using namespace std;

int main(){
    print_hello();
    cout << endl;
    cout << "The factorial of 7 is " << factorial(7) << endl;
    return 0;
}
