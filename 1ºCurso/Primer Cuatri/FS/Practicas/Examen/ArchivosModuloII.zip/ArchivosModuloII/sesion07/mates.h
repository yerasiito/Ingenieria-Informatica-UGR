#include <iostream>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

void print_sin(float valor);
void print_cos(float valor);
void print_tan(float valor);
