#!/bin/bash 

if  [[ $1 == "-a" ]]
then
find / -user pat -root
elif [[ $1 == "-b" ]]
then
find . -type f -atime -6

elif [[ $1 == "-c" ]];
then
% find . -name -not *e* -print
 elif [[ $1 == "-c" ]];
 find .-type f -perm 744
