#!/bin/bash 

if  [[ $1 == "-a" ]]
then
VAR1=`ls -l *cadenaCaracteres* | wc -l`
VAR2=`ls -l *cadenaCaracteres* | wc -c`
	ls -a *cadenaCaracteres*
	printf "El numero de archivos es $VAR1 \n"
	printf "El tamaño total de estos archivos es $VAR2 \n" 

elif [[ $1 == "-b" ]]
then
		if test -e $3 ; then cat $2 >> $3; else touch $3; fi
		
elif [[ $1 == "-c" ]];
then
	dia= `date +%y%m%d`  #suponemos que el archivo y el directorio existen
	touch $2 && mkdir $3
	mv $2 $2-$fecha
	mv $2-$fecha $3
	
elif [[ $1 == "-d" ]]
then
	cat examen1.sh
fi
