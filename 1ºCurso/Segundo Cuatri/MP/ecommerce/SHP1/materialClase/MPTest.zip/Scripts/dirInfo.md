Scripts de apoyo a NetBeans
