# TEST REPORT Mar  5 2021 09:54:43

| TEST | RESULT | COMMENTS |
| :------ | :---: | :---: |
| **_01_Basics.DateTime_Constructors** | **FAILED** | **"c.to_string().c_str()" " must have been equal to " "DATETIME_DEFAULT"** |
| **_01_Basics.DateTime_getters** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.DateTime_set** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.Event_ConstructorBase** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.Event_Setters_getters** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.Integration_ECommerce5** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.Integration_EMPTY** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.Integration_ECommerce49** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.Integration_ECommerce_2019_Q4_200** | **SKIPPED** | **The previous test failed** |
| **_01_Basics.Integration_ECommerce_all_all_200** | **SKIPPED** | **The previous test failed** |
| **_02_Intermediate.DateTime_isBefore** | **SKIPPED** | **The previous test failed** |
| **_02_Intermediate.DateTime_weekDay** | **SKIPPED** | **The previous test failed** |
| **_03_Advanced.DateTime_BadValues** | **SKIPPED** | **The previous test failed** |
| **_03_Advanced.Event_setType_Bad_Values** | **SKIPPED** | **The previous test failed** |
| **_03_Advanced.Event_Others_Bad_Values** | **SKIPPED** | **The previous test failed** |
