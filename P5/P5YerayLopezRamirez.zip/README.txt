LISTA DE TECLAS:
Cambiar de practicas:
  1: Practica 1
  2: Practica 2
  3: Practica 3
  4: Practica 4
  5: Practica 5
p: Modo punto
l: Modo linea
f: Modo relleno
i: Activar/Desactivar iluminacion
y: Modo caras o vertices
Animacion de la bicicleta:
  u: Activar/Desactivar animacion
  E/e: Avanzar o retroceder bici
  T/t: Subir o bajar el asiento
  O/o: pedalear hacia delante/atrás
  N/n: girar ruedas en sentido del reloj/contrareloj
  f: Velocidad x1
  g: Velocidad x2
  h: Velocidad x2.5
  j: Velocidad x2.75
  k: Velocidad x3
c: Alternar luz 1/2 (blanca/roja)
a: Desplaza la camara -x
d: Desplaza la camara +x
w: Desplaza la camara -z
s: Desplaza la camara +z
